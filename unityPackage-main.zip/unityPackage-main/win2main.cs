using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class win2main : MonoBehaviour
{
   
   
   
   public void playbutton ()
   {
	   SceneManager.LoadScene(0); 
	   
   }
  
   
   
   
   
}
