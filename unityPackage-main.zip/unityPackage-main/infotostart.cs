using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class infotostart : MonoBehaviour
{
     
   public void Backbutton ()
   {
	   SceneManager.LoadScene(0); 
	   
   }
}
